import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  try {
    const form = await req.formData();

    const vendorId = form.get("vendorId")?.toString();
    const evidenceType = form.get("evidenceType")?.toString();
    const description = form.get("description")?.toString() || "";
    const file = form.get("file") as File | null;

    if (!vendorId || !file || !evidenceType) {
      return NextResponse.json(
        { error: "Missing required fields." },
        { status: 400 }
      );
    }

    const fileName = `${Date.now()}-${file.name}`;

    // For now we do not persist the actual file anywhere.
    // We keep a placeholder URL so the UI can show something.
    const fileUrl = `/evidence/${fileName}`;

    const evidenceRecord = await prisma.evidence.create({
      data: {
        vendorId: Number(vendorId),
        type: evidenceType,
        description,
        fileName,
        fileUrl,
        size: file.size,
        uploadedAt: new Date(),
      },
    });

    return NextResponse.json(
      { ok: true, evidenceId: evidenceRecord.id },
      { status: 200 }
    );
  } catch (err: any) {
    console.error("Evidence upload failed:", err);
    return NextResponse.json(
      { error: err?.message || "Upload failed" },
      { status: 500 }
    );
  }
}
