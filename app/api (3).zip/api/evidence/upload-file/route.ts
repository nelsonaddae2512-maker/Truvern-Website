// app/api/evidence/upload-file/route.ts
import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  // NOTE: This is a stub. It *does not* persist files yet.
  // It only verifies that we received a multipart request and
  // returns a fake "ok" payload so the UI flow keeps moving.

  try {
    const contentType = req.headers.get('content-type') || '';

    if (!contentType.toLowerCase().includes('multipart/form-data')) {
      return NextResponse.json(
        { error: 'Expected multipart/form-data' },
        { status: 400 },
      );
    }

    // Force-read the body so Next is happy, but ignore contents.
    await req.blob().catch(() => null);

    return NextResponse.json(
      {
        ok: true,
        // placeholder fields so the caller can log something
        message: 'Upload stub reached. File not actually stored yet.',
      },
      { status: 200 },
    );
  } catch (error) {
    console.error('POST /api/evidence/upload-file error', error);
    return NextResponse.json(
      { error: 'Failed to process upload stub' },
      { status: 500 },
    );
  }
}
