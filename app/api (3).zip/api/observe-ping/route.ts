﻿export const runtime = 'nodejs';
import { NextResponse } from 'next/server'
import { log } from '@/app/lib/logger'

export async function GET() {
  log('info', 'observe-ping hit')
  return NextResponse.json({ ok: true, ts: Date.now() })
}