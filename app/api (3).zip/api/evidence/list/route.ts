﻿// app/api/evidence/list/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const url = req.nextUrl;
  const vendorId = url.searchParams.get('vendorId');

  if (!vendorId) {
    return NextResponse.json(
      { error: 'vendorId is required' },
      { status: 400 },
    );
  }

  try {
    const evidence = await (prisma as any).evidence.findMany({
      where: { vendorId: Number(vendorId) },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(
      evidence.map((e: any) => ({
        id: e.id,
        vendorId: e.vendorId,
        title: e.title ?? null,
        type: e.type ?? null,
        createdAt: e.createdAt ?? null,
      })),
      { status: 200 },
    );
  } catch (error) {
    console.error('GET /api/evidence/list error', error);
    return NextResponse.json(
      { error: 'Failed to load evidence' },
      { status: 500 },
    );
  }
}
